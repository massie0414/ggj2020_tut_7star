#include <genesis.h>
/*
 * game.h
 *
 *  Created on: 2020/02/01
 *      Author: 1923126
 */

/*enum game_item {
	WOOD,
	STONE,
	METAL,
	WATER,
};*/

//int[] Buki_Powers=



