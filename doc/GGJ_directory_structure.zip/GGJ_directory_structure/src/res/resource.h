#ifndef _RES_RESOURCE_H_
#define _RES_RESOURCE_H_

extern const u8 BGM_short_01_8[390144];
extern const u8 BGM_Sub_8[1110016];
extern const u8 SE_Explosion_8[54528];
extern const u8 SE_Footstep_8[4352];
extern const u8 SE_Footsteps_cave_8[108544];
extern const u8 SE_Punch_8[6912];
extern const u8 SE_Hammer_8[20480];
extern const TileSet sjis_font;
extern const Image logo16;
extern const Image title_image;

#endif // _RES_RESOURCE_H_
